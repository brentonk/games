.First.lib <- function(library, pkg)
{
    library.dynam("pbivnorm", pkg, library)
}
